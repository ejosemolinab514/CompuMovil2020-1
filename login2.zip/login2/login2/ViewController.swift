//
//  ViewController.swift
//  login2
//
//  Created by Molina Beltrán on 9/16/19.
//  Copyright © 2019 MolinaBeltrán. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var forgotUser: UIButton!
    @IBOutlet weak var forgotPass: UIButton!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else {return}
        if sender == forgotPass {
            segue.destination.navigationItem.title = "Forgot Password"
        } else if sender == forgotUser {
            segue.destination.navigationItem.title = "Forgot User Name"
        } else {
            if password.text == "password" {
                segue.destination.navigationItem.title = userName.text
            } else {
                segue.destination.navigationItem.title = "Wrong Password"
            }
        }
    }
    
    @IBAction func forgotUserClicked(_ sender: Any) {
        performSegue(withIdentifier: "forgotSomething", sender: forgotUser)
    }
    
    @IBAction func forgotPassClicked(_ sender: Any) {
        performSegue(withIdentifier: "forgotSomething", sender: forgotPass)
    }
    
}

