import UIKit

let temperature = 76
switch temperature {
case 65...75:
    print("The temperature is just right")
case 76...Int.max:
    print("It's too hot.")
default:
    print("It's too cold")
}


func displayPi() {
    print("3.1415926535")
}
//displayPi()


func triple(value: Int) {
    let result = value * 3
    print("If you multiply \(value) by 3, you'll get \(result)")
}
//triple(value: 10)


func multiply(_ firstNumber: Int = 1, by secondNumber: Int = 1) -> Int {
    let result = firstNumber * secondNumber
    return result
}
//print(multiply())


func display(teamName: String, score: Int = 0) {
    print("\(teamName): \(score)")
}
//display(teamName: "Wombats", score: 100)
//display(teamName: "Wombats")


struct Person {
    var name: String
    var age: Int
    func sayHello() {
        print("Hello, my name is \(name), my age is \(age)")
    }
}
let person = Person(name: "Ernesto José", age: 22)
print(person.name)
person.sayHello()

let string = String.init()
let integer = Int.init()
let bool = Bool.init()
