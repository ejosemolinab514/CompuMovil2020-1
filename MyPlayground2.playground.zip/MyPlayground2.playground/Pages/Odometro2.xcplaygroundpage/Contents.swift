import Foundation

struct StepCounter {
    var totalSteps: Int = 0 {
        willSet {
            print("About to set total steps to \(newValue)")
        }
        didSet {
            print("Added \(totalSteps - oldValue) steps")
        }
    }
}
var stepCounter = StepCounter()
stepCounter.totalSteps = 10
stepCounter.totalSteps = 45
stepCounter.totalSteps = 36
