import UIKit
struct Temperature {
    var celsius: Double
    var fahrenheit: Double
    var kelvin: Double
    init(c celsius: Double) {
        var cel = celsius
        if(cel < -273.15){
            cel = -273.15
        }
        self.celsius = cel
        fahrenheit = self.celsius * 1.8 + 32
        kelvin = self.celsius+273.15
    }
    init(f fahrenheit: Double) {
        self.init(c: (fahrenheit - 32)/1.8)
    }
    init(k kelvin: Double) {
        self.init(c: kelvin-273.15)
    }
    init() {
        self.init(c: 0)
    }
}
let tem1 = Temperature(c: 0)
let tem2 = Temperature(f: 32)
let tem3 = Temperature(k: 273.15)
let tem4 = Temperature()
