import Foundation
struct Temperature {
    var bandera: Bool = true
    var celsius: Double {
        willSet{
            if(bandera){
                bandera = false
                fahrenheit = newValue * 1.8 + 32
                kelvin = celsius + 273.15
                bandera = true
            }
        }
    }
    var fahrenheit: Double {
        willSet{
            if(bandera){
                bandera = false
                celsius = (newValue - 32) / 1.8
                kelvin = celsius + 273.15
                bandera = true
            }
        }
    }
    var kelvin: Double {
        willSet {
            if(bandera){
                bandera = false
                celsius = newValue - 273.15
                fahrenheit = celsius * 1.8 + 32
                bandera = true
            }
        }
    }
    init(c celsius: Double) {
        self.celsius = celsius
        fahrenheit = self.celsius * 1.8 + 32
        kelvin = self.celsius+273.15
    }
    init(f fahrenheit: Double) {
        self.init(c: (fahrenheit - 32)/1.8)
    }
    init(k kelvin: Double) {
        self.init(c: kelvin-273.15)
    }
    init() {
        self.init(c: 0)
    }
}
var tem = Temperature(c: 0)
tem.fahrenheit = 86
tem.kelvin = 0
