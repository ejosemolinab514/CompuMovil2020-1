import Foundation

struct Odometer {
    var count: Int = 0
    mutating func increment() {
        count += 1
    }
    mutating func reset() {
        count = 0
    }
}

var odometer = Odometer()
print(odometer.count)
odometer.increment()
print(odometer.count)
odometer.reset()
print(odometer.count)
