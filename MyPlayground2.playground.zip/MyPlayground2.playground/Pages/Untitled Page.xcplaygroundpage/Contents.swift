import UIKit
struct Temperature {
    var celsius: Double
    var fahrenheit: Double
    init(c celsius: Double) {
        self.celsius = celsius
        fahrenheit = self.celsius * 1.8 + 32
    }
    init(f fahrenheit: Double) {
        self.fahrenheit = fahrenheit
        celsius = (self.fahrenheit - 32)/1.8
    }
    init(k kelvin: Double) {
        self.init(c: kelvin-273.15)
    }
    init() {
        self.init(c: 0)
    }
}
let temp = Temperature(c: 30.0)
let tem2 = Temperature(f: 86)
let tem3 = Temperature(k: 303.15)
let tem4 = Temperature()
let text = String.init()
