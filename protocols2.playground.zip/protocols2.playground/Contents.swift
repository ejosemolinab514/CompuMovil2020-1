import UIKit

enum DrinkSize {
    case can225, can355, can473, can735
}

protocol Drink {
    var volume: Double {get set}
    var caffeine: Double {get set}
    var temperature: Double {get set}
    var drinkSize: DrinkSize {get set}
    var description: String {get set}
}

extension Drink{
    mutating func drinking(amount: Double){
        volume -= amount
    }
    
    mutating func temperatureChange(change: Double){
        temperature += change
    }
}

struct Monster: Drink {
    var volume: Double
    var caffeine: Double
    var temperature: Double
    var drinkSize: DrinkSize
    var description: String
    
    init(temperature: Double){
        self.temperature = temperature
        self.volume = 473
        self.caffeine = 0.5
        self.description = ("Bebida para que ella ya te ame")
        self.drinkSize = .can473
    }
}

struct CocaCola: Drink {
    var volume: Double
    var caffeine: Double
    var temperature: Double
    var drinkSize: DrinkSize
    var description: String
    
    init(volume: Double, temperature: Double, drinkSize: DrinkSize){
        self.temperature = temperature
        self.volume = volume
        self.caffeine = 0
        self.description = ("Aguas negras del capitalismo")
        self.drinkSize = drinkSize
    }
}

class Cooler {
    var temperature: Double
    var cansOfDrinks = [Drink]()
    var maxCans: Int
    
    init(temperature: Double, maxCans: Int) {
        self.temperature = temperature
        self.maxCans = maxCans
    }
    
    func addDrink(drink: Drink) -> Bool {
        if cansOfDrinks.count < maxCans {
            cansOfDrinks.append(drink)
            return true
        } else {
            print("No se puede agregar la bebida")
            return false
        }
    }
    
    func removeDrink(drink: Drink) -> Drink? {
        if cansOfDrinks.count > 0 {
            return cansOfDrinks.removeFirst()
        } else {
            return nil
        }
    }
}

let refriOS = Cooler.init(temperature: 10, maxCans: 15)
let myMonster = Monster(temperature: 6.1)
let myCoke = CocaCola(volume: 355.0, temperature: 2.9, drinkSize: .can355)

for _ in 0...5 {
    refriOS.addDrink(drink: myMonster)
}

print(refriOS.cansOfDrinks)

for _ in 0...5 {
    refriOS.addDrink(drink: myCoke)
}

print(refriOS.cansOfDrinks)
