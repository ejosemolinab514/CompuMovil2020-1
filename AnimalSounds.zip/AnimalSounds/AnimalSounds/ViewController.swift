//
//  ViewController.swift
//  AnimalSounds
//
//  Created by 2020-1 on 8/30/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let mooSound = SimpleSound(named: "moo")
    let woofSound = SimpleSound(named: "woof")
    let meowSound = SimpleSound(named: "meow")

    @IBOutlet weak var animalSoundLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func catButtonTapped(_ sender: Any) {
        animalSoundLabel.text="Meow"
        meowSound.play()
    }
    
    @IBAction func dogButtonTapped(_ sender: Any) {
        animalSoundLabel.text="Woof"
        woofSound.play()
    }
    
    @IBAction func cowButtonTapped(_ sender: Any) {
        animalSoundLabel.text="Moo"
        mooSound.play()
    }
}

