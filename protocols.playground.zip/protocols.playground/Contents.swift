import UIKit

class Shoe: CustomStringConvertible {
    var description: String {
        return "Shoe(Size: \(size), Brand: \(brand), Color: \(color))"
    }
    let size: Double
    let brand: String
    let color: String
    
    init(color: String, brand: String, size: Double) {
        self.color = color
        self.brand = brand
        self.size = size
    }
}

let myShoe = Shoe(color: "gray", brand: "Lacoste", size: 7.5)
let juanShoe = Shoe(color: "gray", brand: "DC", size: 6.5)

print(myShoe)
print(juanShoe)

protocol Saltar {
    func salta()
}

protocol Sanar {
    func sana()
}

class Jugador: Saltar {
    func salta() {
        print("Salto como el SERRESIETE")
    }
}

class Guerrero: Saltar {
    func salta() {
        print("Salto como jugador del Santos (Guerrero)")
    }
    
    func callateWarriorCallateWarriorCallateWarriorMalditaSea() {
        print("Me voy del estadio")
    }
}

class Mago: Saltar, Sanar {
    func salta() {
        print("Salto como Messi (Mago)")
    }
    
    func sana() {
        print("Te salva la vida")
    }
}

var oz = Mago()
var warrior = Guerrero()
var cr7 = Jugador()

func hazloSaltar(_ saltador: Saltar){
    saltador.salta()
}

hazloSaltar(cr7)
hazloSaltar(warrior)
hazloSaltar(oz)
warrior.callateWarriorCallateWarriorCallateWarriorMalditaSea()
