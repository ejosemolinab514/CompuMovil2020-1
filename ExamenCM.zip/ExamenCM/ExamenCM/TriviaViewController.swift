
//
//  ViewController.swift
//  ExamenCM
//
//  Created by 2020-1 on 9/20/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class TriviaViewController: UIViewController {
    @IBOutlet weak var pregunta1: UISwitch!
    @IBOutlet weak var pregunta2: UISwitch!
    @IBOutlet weak var pregunta3: UISwitch!
    @IBOutlet weak var pregunta4: UISwitch!
    @IBOutlet weak var revisionButton: UIButton!
    var correcto = false
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.hideKeyboardWhenTappedAround()
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let resultadoVC = segue.destination as! ResultadosViewController
        if correcto {
            resultadoVC.correcto = "Nos gusta premiar a los grandes fans como tú.\nTOMA TU CÓDIGO AMIGO.\n\nCP20OFF"
            resultadoVC.view.backgroundColor = UIColor.green
        } else {
            resultadoVC.correcto = "ANDAS MÁS COLD QUE PLAY.\nINTENTA DE NUEVO! :c"
            resultadoVC.view.backgroundColor = UIColor.red
        }
    }
    
    @IBAction func revisarIsClicked(_ sender: Any) {
        if pregunta1.isOn && !pregunta2.isOn && pregunta3.isOn && !pregunta4.isOn {
            correcto = true
        }else{
            correcto = false
        }
        performSegue(withIdentifier: "Revisar", sender: revisionButton)
    }
    
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

