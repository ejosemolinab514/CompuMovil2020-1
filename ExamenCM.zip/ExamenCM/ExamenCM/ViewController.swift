//
//  ViewController.swift
//  ExamenCM
//
//  Created by 2020-1 on 9/20/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var crediButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

