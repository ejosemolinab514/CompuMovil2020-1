//
//  ViewController.swift
//  ExamenCM
//
//  Created by 2020-1 on 9/20/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class DetalleViewController: UIViewController {
    
    @IBOutlet weak var portada: UIImageView!
    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var tracklist: UILabel!
    var imagen: UIImage = #imageLiteral(resourceName: "mx")
    var titul = "HOLA"
    var tlist = "adios"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        portada.image = imagen
        titulo.text = titul
        tracklist.text = tlist
        navigationItem.title = titul
    }
    
}

class discosViewController: UIViewController {
    @IBOutlet weak var parachutes: UIButton!
    @IBOutlet weak var arobtth: UIButton!
    @IBOutlet weak var xy: UIButton!
    @IBOutlet weak var vlv: UIButton!
    @IBOutlet weak var mx: UIButton!
    @IBOutlet weak var gs: UIButton!
    @IBOutlet weak var ahfod: UIButton!
    
    var nombreDisco = "Parachutes"
    var tracklist = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func cdTapped(_ sender: Any) {
        performSegue(withIdentifier: "discoSegue", sender: sender)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let discoVC = segue.destination as? DetalleViewController {
            let boton = sender as! UIButton
            if boton == parachutes{
                discoVC.imagen = #imageLiteral(resourceName: "parachutes")
                discoVC.titul = "Parachutes"
                discoVC.tlist = """
                1. Dont Panic
                2. Shiver
                3. Spies
                4. Sparks
                5. Yellow
                6. Trouble
                7. Parachutes
                8. High Speed
                9. We Never Change
                10 Everything's Not Lost
                """
            }else if boton == arobtth{
                discoVC.imagen = #imageLiteral(resourceName: "arobtth")
                discoVC.titul = "A Rush Of Blood to the Head"
                discoVC.tlist = """
                1. Politik
                2. In My Place
                3. God Put a Smile upon Your Face
                4. The Scientist
                5. Clocks
                6. Daylights
                7. Green Eyes
                8. Warning Sign
                9. A Whisper
                10. A Rush of Blood to th Head
                11. Amsterdam
                """
            }else if boton == xy{
                discoVC.imagen = #imageLiteral(resourceName: "xy")
                discoVC.titul = "X&Y"
                discoVC.tlist = """
                1. Square One
                2. What If
                3. White Shadows
                4. Fix You
                5. Talk
                6. X&Y
                7. Speed Of Sound
                8. A Message
                9. Low
                10. The Hardest Part
                11. Swallowed in the Sea
                12. Twisted Logic
                """
            }else if boton == vlv{
                discoVC.imagen = #imageLiteral(resourceName: "vlv")
                discoVC.titul = "Viva La Vida"
                discoVC.tlist = """
                1. Life in Technicolor
                2. Cemeteries of London
                3. Lost!
                4. 42
                5. Lovers in Japan/Reign of Love
                6. Yes
                7. Viva La Vida
                8. Violet Hill
                9. Strawberry Swing
                10. Death And All His Friends
                """
            }else if boton == mx{
                discoVC.imagen = #imageLiteral(resourceName: "mx")
                discoVC.titul = "Mylo Xyloto"
                discoVC.tlist = """
                1. Mylo Xyloto
                2. Hurts Like Heaven
                3. Paradise
                4. Charlie Brown
                5. Us Against the World
                6. M.M.I.X.
                7. Every Teardrop is a Waterfall
                8. Major Minus
                9. U.F.O.
                10. Princess Of China
                11. Up in Flames
                12. A Hopeful Transmission
                13. Don't Let It Break Your Heart
                14. Up with the Birds
                """
            }else if boton == gs{
                discoVC.imagen = #imageLiteral(resourceName: "gs")
                discoVC.titul = "Ghost Stories"
                discoVC.tlist = """
                1. Always In My Head
                2. Magic
                3. Ink
                4. True Love
                5. Midnight
                6. Another's Arms
                7. Oceans
                8. A Sky Full Of Stars
                9. O
                """
            }else if boton == ahfod{
                discoVC.imagen = #imageLiteral(resourceName: "ahfod")
                discoVC.titul = "A Head Full Of Dreams"
                discoVC.tlist = """
                1. A Head Full Of Dreams
                2. Birds
                3. Hymn fot the Weekend
                4. Everglow
                5. Adventure Of a Lifetime
                6. Fun (feat. Tove Lo)
                7. Kaleidoscope
                8. Army of One / X Marks the Spot
                9. Amazing Day
                10. Color Spectrum
                11. Up&Up
                """
            }else{
                discoVC.imagen = #imageLiteral(resourceName: "xy")
                discoVC.titul = "Kaleidoscope EP"
                discoVC.tlist = "SIN CANCIONES xdd"
            }
        }
    }
    
}

