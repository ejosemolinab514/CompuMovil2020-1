//
//  ViewController.swift
//  ExamenCM
//
//  Created by 2020-1 on 9/20/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class SouvenirViewController: UIViewController {
    @IBOutlet weak var c1: UITextField!
    @IBOutlet weak var c2: UITextField!
    @IBOutlet weak var promo: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.hideKeyboardWhenTappedAround()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var desc: Double
        let detalleCompraVC = segue.destination as! detalleCompraViewController
        if promo.text == "CP20OFF" {
            desc = 0.8
        }else{
            desc = 1
        }
        if let valor1: String = c1.text, let valor2: String = c2.text {
            let cant1 = Double(valor1)
            let cant2 = Double(valor2)
            if cant1! >= 0.0, cant2! >= 0.0 {
                detalleCompraVC.correcto = (cant1! * 750.0 + cant2! * 500.0)*desc
                detalleCompraVC.view.backgroundColor = UIColor.green
            }else{
                detalleCompraVC.correcto = -1
                detalleCompraVC.view.backgroundColor = UIColor.red
            }
        }else{
            detalleCompraVC.correcto = -1
            detalleCompraVC.view.backgroundColor = UIColor.red
        }
    }
    
    @IBAction func comprarIsClicked(_ sender: Any) {
        performSegue(withIdentifier: "comprarSegue", sender: sender)
    }
}

class detalleCompraViewController: UIViewController {
    
    @IBOutlet weak var total: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label1: UILabel!
    
    var correcto: Double! = 1.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if correcto >= 0 {
            total.text = String(format:"$ %.2f", correcto)
        }else{
            label1.text = "No se pudo procesar."
            label2.text = "Error:"
            total.text = "DATOS NO VÁLIDOS"
        }
    }
    
}
