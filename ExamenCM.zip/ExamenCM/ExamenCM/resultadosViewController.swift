//
//  resultadosViewController.swift
//  ExamenCM
//
//  Created by 2020-1 on 9/20/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class ResultadosViewController: UIViewController {
    var correcto: String!
    
    @IBOutlet weak var resultado: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resultado.text = correcto
    }
    
}
